
export const jwtConstants = {
    secret: 'SUPER-SECRET-CODE',
  };
  